Download and copy d3.v3.js into the folder where you have your JavaScript files.
If you don't download d3.v3.js, use the following <script> tag:
<script src="http://d3js.org/d3.v3.js"></script>
